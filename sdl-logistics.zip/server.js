
import express from 'express';
import session from 'express-session';
import fs from 'fs';
import WebSocket from 'ws';

const app = express();
app.use(express.json());
app.use(session({ secret: 'sdl-secret', resave: false, saveUninitialized: false }));
app.use(express.static('public'));

const DRIVERS_DB = './drivers.json';
const SETTINGS = './security-settings.json';

if (!fs.existsSync(DRIVERS_DB)) fs.writeFileSync(DRIVERS_DB, '{}');
if (!fs.existsSync(SETTINGS)) fs.writeFileSync(SETTINGS, JSON.stringify({
  allowedCountries: ["US"],
  failedLoginLimit: 5,
  autoLock: { onCountryMismatch: true, lockHours: 6 }
}, null, 2));

// --- WebSocket for live map ---
const wss = new WebSocket.Server({ port: 8080 });
const adminClients = new Set();
wss.on('connection', ws => {
  ws.on('message', msg => {
    const d = JSON.parse(msg.toString());
    if (d.type === 'ADMIN_MAP') adminClients.add(ws);
  });
  ws.on('close', () => adminClients.delete(ws));
});
function broadcast(payload){
  const msg = JSON.stringify(payload);
  adminClients.forEach(ws => ws.readyState===WebSocket.OPEN && ws.send(msg));
}

// --- Basic routes (placeholders for your full system) ---
app.get('/health', (req,res)=>res.json({ok:true}));

app.post('/login', (req,res)=>{
  const { driverId } = req.body;
  const db = JSON.parse(fs.readFileSync(DRIVERS_DB));
  if(!db[driverId]) db[driverId] = { ipHistory: [] };
  const now = new Date().toISOString();
  const record = { ip: '0.0.0.0', country: 'US', lat: 40.7, lng: -74.0, status: 'success', date: now };
  db[driverId].ipHistory.push(record);
  fs.writeFileSync(DRIVERS_DB, JSON.stringify(db,null,2));

  broadcast({ type:'LIVE_LOGIN', driverId, ...record });
  req.session.driver = driverId;
  res.json({ success:true });
});

app.get('/admin/logins-last-24h', (req,res)=>{
  const db = JSON.parse(fs.readFileSync(DRIVERS_DB));
  const cutoff = Date.now() - 24*3600000;
  const events = [];
  Object.entries(db).forEach(([id,d])=>{
    (d.ipHistory||[]).filter(h=>new Date(h.date).getTime()>=cutoff)
      .forEach(h=>events.push({driverId:id, ...h}));
  });
  res.json(events);
});

app.listen(3000, ()=>console.log('Server running on http://localhost:3000'));
